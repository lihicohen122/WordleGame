﻿namespace Ex02
{
    public class Program
    {
        public static void Main()
        {
            GameInterface newGame = new GameInterface();
            newGame.RunGame();
        }
    }
}
